<?php
/* Smarty version 3.1.29, created on 2016-03-24 15:37:08
  from "C:\Program Files (x86)\wamp\www\tp_tli_4irc\templates\connexion\connexion.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56f3fb94d5bca2_66240467',
  'file_dependency' => 
  array (
    'c64ffb9bd02f1e5a2128ab246043805601a01ab8' => 
    array (
      0 => 'C:\\Program Files (x86)\\wamp\\www\\tp_tli_4irc\\templates\\connexion\\connexion.tpl',
      1 => 1458829422,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_56f3fb94d5bca2_66240467 ($_smarty_tpl) {
?>
<form method="GET" action="sessions" id="formConnexion">
    <input type="hidden" name="_method" value="POST">
    <ul>
        <li>
            <label for="login"> Pseudonyme </label>
            <input id="login" name="login" type="text" />
        </li>
        <li>
            <label for="pass"> Mot de passe </label>
            <input id="pass" name="pass" type="password" />
        </li>
        <li>
            <button id="submit">Envoyer</button> 
        </li>
    </ul>
</form>
<?php }
}
