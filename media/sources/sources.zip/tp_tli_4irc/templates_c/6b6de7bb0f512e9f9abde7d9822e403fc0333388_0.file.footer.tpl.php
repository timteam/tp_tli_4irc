<?php
/* Smarty version 3.1.29, created on 2016-04-05 10:40:45
  from "C:\Program Files (x86)\wamp\www\tp_tli_4irc\templates\footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57037a0dce5f77_85605734',
  'file_dependency' => 
  array (
    '6b6de7bb0f512e9f9abde7d9822e403fc0333388' => 
    array (
      0 => 'C:\\Program Files (x86)\\wamp\\www\\tp_tli_4irc\\templates\\footer.tpl',
      1 => 1459845580,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57037a0dce5f77_85605734 ($_smarty_tpl) {
?>
<footer>
    &copy; Copyright Troncy, Cicuto, Oziol, Bouquet - 4IRC 2016
</footer><?php }
}
