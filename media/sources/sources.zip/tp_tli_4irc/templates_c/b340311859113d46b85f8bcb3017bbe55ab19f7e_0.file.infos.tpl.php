<?php
/* Smarty version 3.1.29, created on 2016-04-27 16:34:31
  from "C:\Program Files (x86)\wamp\www\tp_tli_4irc\templates\infos.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5720cdf7aac507_43528403',
  'file_dependency' => 
  array (
    'b340311859113d46b85f8bcb3017bbe55ab19f7e' => 
    array (
      0 => 'C:\\Program Files (x86)\\wamp\\www\\tp_tli_4irc\\templates\\infos.tpl',
      1 => 1461767670,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5720cdf7aac507_43528403 ($_smarty_tpl) {
?>
<div id="main">
    <h1>Informations<hr/></h1>
    
    <h2>L'équipe de développeurs</h2>

    <div id="auteurs">
        <nav>
            <ul>
                <li><img class="img-rounded" src="media/images/devs/thimothee.jpg" alt="Photo de Thimothée">Timothée Troncy</li>
                <li><img class="img-rounded" src="media/images/devs/valentin.jpg" alt="Photo de Valentin">Valentin Cicuto</li>
                <li><img class="img-rounded" src="media/images/devs/brandon.jpg" alt="Photo de Brandon">Brandon Oziol</li>
                <li><img class="img-rounded" src="media/images/devs/antoine.jpg" alt="Photo de Antoine">Antoine Bouquet</li>
            </ul>
        </nav>
    </div>

    <h2>Webographie</h2>

    <div id="webographie">
        <ul>
            <li>Page Wikipédia de l'acupunture : <a href="http://www.passeportsante.net/fr/Therapies/Guide/Fiche.aspx?doc=acupuncture_th" title="PasseportSante.net" accesskey="&">http://passeportsante.net/</a></li>
            <li>Utilisation des champs Select2 de JQuery : <a href="https://select2.github.io/" title="Select2" accesskey="2">https://select2.github.io/</a></li>
            <li>Utilisation de la machine virtuelle Lubuntu : <a href="http://lubuntu.net" title="Lubuntu" accesskey="3">http://lubuntu.net</a></li>
            <li>Site PHP.net : <a href="http://php.net" title="PHP" accesskey="5">http://php.net</a></li>
            <li>Site JQuery.com : <a href="https://jquery.com" title="JQuery" accesskey="6">https://jquery.com</a></li>
            <li>Site W3Schools.com : <a href="http://www.w3schools.com" title="W3Schools" accesskey="7">http://www.w3schools.com</a></li>
            <li>Site passeportsante.net : <a href="http://www.passeportsante.net/" title="Passeport santé - inspiration css et texte" accesskey="8">http://www.passeportsante.net/</a></li>
            <li>Site medecinechinoise.org : <a href="http://www.medecinechinoise.org/" title="Médecine chinoise - inspiration css et texte" accesskey="9">http://www.medecinechinoise.org/</a></li>
        </ul>
    </div>

    <h2>Sources</h2>

</div>
<?php }
}
