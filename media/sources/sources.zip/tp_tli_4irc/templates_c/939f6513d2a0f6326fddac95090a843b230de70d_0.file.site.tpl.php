<?php
/* Smarty version 3.1.29, created on 2016-04-27 14:25:00
  from "C:\Program Files (x86)\wamp\www\tp_tli_4irc\templates\site.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5720af9cba5ef0_33203160',
  'file_dependency' => 
  array (
    '939f6513d2a0f6326fddac95090a843b230de70d' => 
    array (
      0 => 'C:\\Program Files (x86)\\wamp\\www\\tp_tli_4irc\\templates\\site.tpl',
      1 => 1461574100,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5720af9cba5ef0_33203160 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Acupunctura - Medecine chinoise millénaire</title>
    <base href="<?php echo $_smarty_tpl->tpl_vars['route']->value;?>
" />
    <meta content="Acupunctura - Medecine chinoise millénaire" name="description">
    <link type="text/css" rel="stylesheet" href="https://code.jquery.com/ui/jquery-ui-git.css">
    <link type="text/css" rel="stylesheet" href="/media/css/select2.min.css">
    <link type="text/css" rel="stylesheet" href="/media/css/site.css">
    <?php echo '<script'; ?>
  type="text/javascript" charset="UTF-8" src="https://code.jquery.com/jquery-1.12.0.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
  type="text/javascript" charset="UTF-8" src="https://code.jquery.com/ui/1.12.0-beta.1/jquery-ui.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" charset="UTF-8" src="/media/javascript/select2.full.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" charset="UTF-8" src="/media/javascript/site.js"><?php echo '</script'; ?>
>
  </head>
  <body>
        <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('user'=>$_smarty_tpl->tpl_vars['user']->value), 0, false);
?>

        <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['module']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('argument'=>$_smarty_tpl->tpl_vars['argument']->value,'user'=>$_smarty_tpl->tpl_vars['user']->value), 0, true);
?>

        <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

        <div id="popup"></div>
  </body>
</html><?php }
}
