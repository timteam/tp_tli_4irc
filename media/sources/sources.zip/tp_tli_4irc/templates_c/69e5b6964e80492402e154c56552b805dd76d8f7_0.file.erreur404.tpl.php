<?php
/* Smarty version 3.1.29, created on 2016-03-24 14:08:06
  from "C:\Program Files (x86)\wamp\www\tp_tli_4irc\templates\erreur404.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56f3e6b65f6c19_01238843',
  'file_dependency' => 
  array (
    '69e5b6964e80492402e154c56552b805dd76d8f7' => 
    array (
      0 => 'C:\\Program Files (x86)\\wamp\\www\\tp_tli_4irc\\templates\\erreur404.tpl',
      1 => 1458823645,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_56f3e6b65f6c19_01238843 ($_smarty_tpl) {
?>
<div id="main">
    <h1>Désolé, cette page est introuvable !</h1>
    </br>
    <p>Vous pouvez consulter <a href="pathologies" >la liste des pathologies</a> ou <a href="home">retourner à l'accueil du site</a>.</p>
</div>
<?php }
}
