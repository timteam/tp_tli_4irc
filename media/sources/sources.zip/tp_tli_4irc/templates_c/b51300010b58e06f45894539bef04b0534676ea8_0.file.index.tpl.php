<?php
/* Smarty version 3.1.29, created on 2016-03-11 13:15:32
  from "C:\Program Files (x86)\wamp\www\tp_tli_4irc\templates\index.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56e2b6e413df97_80371201',
  'file_dependency' => 
  array (
    'b51300010b58e06f45894539bef04b0534676ea8' => 
    array (
      0 => 'C:\\Program Files (x86)\\wamp\\www\\tp_tli_4irc\\templates\\index.tpl',
      1 => 1457620276,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_56e2b6e413df97_80371201 ($_smarty_tpl) {
}
}
