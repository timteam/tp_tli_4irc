<?php
/* Smarty version 3.1.29, created on 2016-04-23 14:07:21
  from "C:\Program Files (x86)\wamp\www\tp_tli_4irc\templates\pathologieTableau.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_571b657963a691_32381604',
  'file_dependency' => 
  array (
    'bf981db5087bc228bf3b505e9a115c96c1809260' => 
    array (
      0 => 'C:\\Program Files (x86)\\wamp\\www\\tp_tli_4irc\\templates\\pathologieTableau.tpl',
      1 => 1460232875,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_571b657963a691_32381604 ($_smarty_tpl) {
?>
<table id="tableauPatho">
    <thead>
        <tr>
            <th>Méridien</th>
            <th>Pathologies</th>
            <th>Symptômes</th>
        </tr>
    </thead>   
    <tbody>  
        <?php
$_from = $_smarty_tpl->tpl_vars['argument']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_objet_0_saved_item = isset($_smarty_tpl->tpl_vars['objet']) ? $_smarty_tpl->tpl_vars['objet'] : false;
$__foreach_objet_0_saved_key = isset($_smarty_tpl->tpl_vars['meridien']) ? $_smarty_tpl->tpl_vars['meridien'] : false;
$_smarty_tpl->tpl_vars['objet'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['meridien'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['objet']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['meridien']->value => $_smarty_tpl->tpl_vars['objet']->value) {
$_smarty_tpl->tpl_vars['objet']->_loop = true;
$__foreach_objet_0_saved_local_item = $_smarty_tpl->tpl_vars['objet'];
?>
        <tr>
            <td rowspan="<?php echo count($_smarty_tpl->tpl_vars['objet']->value);?>
 ">
                <?php echo $_smarty_tpl->tpl_vars['meridien']->value;?>

            </td>
            <?php
$_from = $_smarty_tpl->tpl_vars['objet']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_patho_1_saved_item = isset($_smarty_tpl->tpl_vars['patho']) ? $_smarty_tpl->tpl_vars['patho'] : false;
$__foreach_patho_1_saved_key = isset($_smarty_tpl->tpl_vars['nom']) ? $_smarty_tpl->tpl_vars['nom'] : false;
$_smarty_tpl->tpl_vars['patho'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['nom'] = new Smarty_Variable();
$__foreach_patho_1_first = true;
$_smarty_tpl->tpl_vars['patho']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['nom']->value => $_smarty_tpl->tpl_vars['patho']->value) {
$_smarty_tpl->tpl_vars['patho']->_loop = true;
$_smarty_tpl->tpl_vars['patho']->first = $__foreach_patho_1_first;
$__foreach_patho_1_first = false;
$__foreach_patho_1_saved_local_item = $_smarty_tpl->tpl_vars['patho'];
?>
                <?php if (!$_smarty_tpl->tpl_vars['patho']->first) {?>
                  <tr>
                <?php }?>
                    <td>
                        <?php echo $_smarty_tpl->tpl_vars['nom']->value;?>

                    </td>
                    <td>
                        <?php
$_from = $_smarty_tpl->tpl_vars['patho']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_symptome_2_saved_item = isset($_smarty_tpl->tpl_vars['symptome']) ? $_smarty_tpl->tpl_vars['symptome'] : false;
$__foreach_symptome_2_total = $_smarty_tpl->smarty->ext->_foreach->count($_from);
$_smarty_tpl->tpl_vars['symptome'] = new Smarty_Variable();
$__foreach_symptome_2_iteration=0;
$_smarty_tpl->tpl_vars['symptome']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['symptome']->value) {
$_smarty_tpl->tpl_vars['symptome']->_loop = true;
$__foreach_symptome_2_iteration++;
$_smarty_tpl->tpl_vars['symptome']->last = $__foreach_symptome_2_iteration == $__foreach_symptome_2_total;
$__foreach_symptome_2_saved_local_item = $_smarty_tpl->tpl_vars['symptome'];
?>
                            <?php echo $_smarty_tpl->tpl_vars['symptome']->value->desc;?>

                            <?php if (!$_smarty_tpl->tpl_vars['symptome']->last) {?>
                              ,
                            <?php }?>
                        <?php
$_smarty_tpl->tpl_vars['symptome'] = $__foreach_symptome_2_saved_local_item;
}
if ($__foreach_symptome_2_saved_item) {
$_smarty_tpl->tpl_vars['symptome'] = $__foreach_symptome_2_saved_item;
}
?>
                    </td>
                </tr>
            <?php
$_smarty_tpl->tpl_vars['patho'] = $__foreach_patho_1_saved_local_item;
}
if ($__foreach_patho_1_saved_item) {
$_smarty_tpl->tpl_vars['patho'] = $__foreach_patho_1_saved_item;
}
if ($__foreach_patho_1_saved_key) {
$_smarty_tpl->tpl_vars['nom'] = $__foreach_patho_1_saved_key;
}
?>
        <?php
$_smarty_tpl->tpl_vars['objet'] = $__foreach_objet_0_saved_local_item;
}
if ($__foreach_objet_0_saved_item) {
$_smarty_tpl->tpl_vars['objet'] = $__foreach_objet_0_saved_item;
}
if ($__foreach_objet_0_saved_key) {
$_smarty_tpl->tpl_vars['meridien'] = $__foreach_objet_0_saved_key;
}
?>
    </tbody>
</table><?php }
}
