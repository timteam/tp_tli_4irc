<?php
/* Smarty version 3.1.29, created on 2016-03-24 16:18:41
  from "C:\Program Files (x86)\wamp\www\tp_tli_4irc\templates\connexion\inscription.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56f40551714eb5_72113892',
  'file_dependency' => 
  array (
    'd64df7a625a3e680aee4e5844691d8330311598b' => 
    array (
      0 => 'C:\\Program Files (x86)\\wamp\\www\\tp_tli_4irc\\templates\\connexion\\inscription.tpl',
      1 => 1458829436,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_56f40551714eb5_72113892 ($_smarty_tpl) {
?>
<form method="GET" action="users" id="formConnexion">
    <input name="_method" type="hidden" value="POST" />
    <ul>
        <li>
            <label for="login"> Pseudonyme </label>
            <input id="login" name="login" type="text"  />
        </li>
        <li>
            <label for="email"> Email </label>
            <input id="email" name="email" type="email"  />
        </li>
        <li>
            <label for="pass"> Mot de passe </label>
            <input id="pass" name="pass" type="password" />
        </li>
        <li>
            <button id="submit">Envoyer</button> 
        </li>
    </ul>
</form>
<?php }
}
