<?php
/* Smarty version 3.1.29, created on 2016-04-27 15:11:28
  from "C:\Program Files (x86)\wamp\www\tp_tli_4irc\templates\header.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5720ba80853fd1_24444328',
  'file_dependency' => 
  array (
    '8be21817066ed0a10b2305dc9d375adc6f70cfb2' => 
    array (
      0 => 'C:\\Program Files (x86)\\wamp\\www\\tp_tli_4irc\\templates\\header.tpl',
      1 => 1461762682,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5720ba80853fd1_24444328 ($_smarty_tpl) {
?>
       <header>
            <?php if ($_smarty_tpl->tpl_vars['user']->value == false) {?>
                <div id="join" class="ajax-popup" data-href="sessions" data-titre="Connexion à Acupuntura">
                    Connexion
                </div>
                <div id="login" class="ajax-popup" data-href="users/register" data-titre="Inscription à Acupuntura">
                    Inscription
                </div>
            <?php } else { ?>
                <div id="loginOn">
                    Bonjour <?php echo $_smarty_tpl->tpl_vars['user']->value;?>

                </div>
                <div id="logout" class="logout-class" data-href="sessions" data-titre="Déconnexion à Acupuntura">
                    Déconnexion
                </div>
            <?php }?>
            <div id="titre">
                ACUPUNTURA
            </div>
            <div id="soustitre">
                <span>U</span>ne <span>M</span>édecine <span>M</span>illénaire <span>C</span>hinoise
            </div>
            <div id="navigation">
                <nav>
                    <ul>
                        <li><img alt="Accueil" src="http://www.medecinechinoise.org/images/pagode.png"><a href="home">Accueil</a></li>
                        <li><a href="pathologies">Les pathologies</a></li>
                        <li><a href="infos">Informations</a></li>
                    </ul>
                </nav>
            </div>
        </header>
        <hr />
<?php }
}
